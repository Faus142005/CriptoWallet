package funcionalidadesVentana;

public interface CriptoWalletControlador {
	
	public abstract void actualizar();
	public abstract void ingresoVentana();
}
