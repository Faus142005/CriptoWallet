package clases;

/**
 * ChatEnVivo contiene funcionalidades 
 * para poder usar el chat
 * @author Fausto Y Albertina
 */

public class ChatEnVivo {

	//Otras clases hechas por nosotros
	private Chat chat;

	/**
	 * @return El chat
	 */
	public Chat getChat() {
		return chat;
	}

	/**
	 * @param chat El chat para setear
	 */
	public void setChat(Chat chat) {
		this.chat = chat;
	}
	
	public void enviarMensaje() {
		
	}
	
	public void mostrarChat() {
		
	}
}
