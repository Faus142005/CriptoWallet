package clases;

public class FIAT extends Moneda{
	public FIAT() {}
	
	public FIAT(String nombre, String nomenclatura, double precio) {
		super(nombre, nomenclatura, precio);
	}
}
