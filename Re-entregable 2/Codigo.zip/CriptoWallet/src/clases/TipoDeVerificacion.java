package clases;

/**
 * TipoDeVerificacion sirve para poder verificar 
 * al usuario enviandole un tipo de mensaje a alguna casilla
 * @author Fausto Y Albertina
 */

public abstract class TipoDeVerificacion {

	public abstract void enviar();
}
